module.exports = {
    'earrape': '500',
    'normal': '100',
};