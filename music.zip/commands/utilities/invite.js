const { MessageEmbed, MessageActionRow, MessageButton } = require('discord.js');

module.exports = {
    config: {
        name: "invite",
        aliases: ["inv", "addme"],
        usage: "(command)",
        category: "utilities",
        description: "Displays all commands that the bot has.",
        accessableby: "Members"
    },
    run: async (client, message, args) => {

      const row = new MessageActionRow()
        .addComponents(
            new MessageButton()
                .setLabel("Invite Me!")
                .setEmoji("936883949916004393")
                .setStyle("LINK")
                .setURL(`https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands`),

                new MessageButton()
                .setLabel("Support Server")
                .setEmoji("940480669556047932")
                .setStyle("LINK")
                .setURL(`https://discord.gg/Y3XpnX3g3y`),

        );

        const embed = new MessageEmbed()
        .setDescription(`Hey <@${message.author.id}>, Enjoy Me Invite Me Today to Your lovely Server [Invite Link](https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot%20applications.commands)`)

        message.channel.send({ embeds: [embed], components: [row] });
    }
}