const MainClient = require("./nanospace");
require('./server')
const client = new MainClient();

client.connect()

module.exports = client; 